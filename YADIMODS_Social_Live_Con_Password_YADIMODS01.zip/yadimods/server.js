const express = require('express');
require('dotenv').config();
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.YOUTUBE_API_KEY || '';
const APP_BASE_URL = (process.env.APP_BASE_URL || process.env.RENDER_EXTERNAL_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const TIKTOK_CLIENT_KEY = process.env.TIKTOK_CLIENT_KEY || '';
const TIKTOK_CLIENT_SECRET = process.env.TIKTOK_CLIENT_SECRET || '';
const INSTAGRAM_APP_ID = process.env.INSTAGRAM_APP_ID || '';
const INSTAGRAM_APP_SECRET = process.env.INSTAGRAM_APP_SECRET || '';
const INSTAGRAM_API_VERSION = process.env.INSTAGRAM_API_VERSION || 'v23.0';
const TIKTOK_REDIRECT_URI = `${APP_BASE_URL}/auth/tiktok/callback`;
const INSTAGRAM_REDIRECT_URI = `${APP_BASE_URL}/auth/instagram/callback`;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const SESSION_SECRET = process.env.SESSION_SECRET || '';
const TOKEN_ENCRYPTION_KEY = process.env.TOKEN_ENCRYPTION_KEY || '';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const TOKEN_FILE = path.join(DATA_DIR, 'connections.enc');
const SESSION_MS = 8 * 60 * 60 * 1000;
const loginAttempts = new Map();

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (APP_BASE_URL.startsWith('https://')) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '5m', index: false }));
app.use(express.json({ limit: '20kb' }));
app.get('/', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

// Cache, OAuth states and encrypted persistent storage for the single-admin deployment.
const cache = new Map();
const oauthStates = new Map();
const connected = { tiktok: null, instagram: null };
const CACHE_MS = 60_000;

function encryptionKey() {
  if (!TOKEN_ENCRYPTION_KEY) return null;
  if (/^[a-f0-9]{64}$/i.test(TOKEN_ENCRYPTION_KEY)) return Buffer.from(TOKEN_ENCRYPTION_KEY, 'hex');
  return crypto.createHash('sha256').update(TOKEN_ENCRYPTION_KEY).digest();
}
function persistConnections() {
  const key = encryptionKey();
  if (!key) return;
  fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(JSON.stringify(connected), 'utf8'), cipher.final()]);
  const payload = JSON.stringify({ v: 1, iv: iv.toString('base64'), tag: cipher.getAuthTag().toString('base64'), data: encrypted.toString('base64') });
  const tempFile = `${TOKEN_FILE}.tmp`;
  fs.writeFileSync(tempFile, payload, { mode: 0o600 });
  fs.renameSync(tempFile, TOKEN_FILE);
}
function loadConnections() {
  const key = encryptionKey();
  if (!key || !fs.existsSync(TOKEN_FILE)) return;
  try {
    const payload = JSON.parse(fs.readFileSync(TOKEN_FILE, 'utf8'));
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(payload.iv, 'base64'));
    decipher.setAuthTag(Buffer.from(payload.tag, 'base64'));
    const raw = Buffer.concat([decipher.update(Buffer.from(payload.data, 'base64')), decipher.final()]).toString('utf8');
    const restored = JSON.parse(raw);
    connected.tiktok = restored.tiktok || null;
    connected.instagram = restored.instagram || null;
  } catch (err) { console.error('No se pudo descifrar data/connections.enc; verifica TOKEN_ENCRYPTION_KEY.', err.message); }
}
function parseCookies(header = '') {
  return Object.fromEntries(header.split(';').map(x => x.trim()).filter(Boolean).map(x => { const i=x.indexOf('='); return i<0?[x,'']:[x.slice(0,i),decodeURIComponent(x.slice(i+1))]; }));
}
function createSession() {
  const expires = Date.now() + SESSION_MS;
  const body = Buffer.from(JSON.stringify({ admin: true, exp: expires })).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}
function validSession(req) {
  if (!ADMIN_PASSWORD || !SESSION_SECRET) return false;
  const token = parseCookies(req.headers.cookie).yadimods_session || '';
  const [body, signature] = token.split('.');
  if (!body || !signature) return false;
  const expected = crypto.createHmac('sha256', SESSION_SECRET).update(body).digest();
  let actual; try { actual = Buffer.from(signature, 'base64url'); } catch { return false; }
  if (actual.length !== expected.length || !crypto.timingSafeEqual(actual, expected)) return false;
  try { const session = JSON.parse(Buffer.from(body, 'base64url').toString('utf8')); return session.admin === true && session.exp > Date.now(); } catch { return false; }
}
function requireAdmin(req, res, next) {
  if (validSession(req)) return next();
  res.status(401).json({ error: 'Inicia sesión como administrador para continuar.', loginRequired: true });
}
loadConnections();
app.get('/api/auth/status', (req, res) => res.json({ configured: Boolean(ADMIN_PASSWORD && SESSION_SECRET), authenticated: validSession(req) }));
app.post('/api/auth/login', (req, res) => {
  if (!ADMIN_PASSWORD || !SESSION_SECRET) return res.status(503).json({ error: 'El administrador aún no está configurado. Define ADMIN_PASSWORD y SESSION_SECRET en el hosting.' });
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const attempt = loginAttempts.get(ip) || { count: 0, blockedUntil: 0 };
  if (attempt.blockedUntil > Date.now()) return res.status(429).json({ error: 'Demasiados intentos. Espera 15 minutos.' });
  const supplied = String(req.body?.password || '');
  const a = Buffer.from(supplied); const b = Buffer.from(ADMIN_PASSWORD);
  const ok = a.length === b.length && crypto.timingSafeEqual(a, b);
  if (!ok) {
    attempt.count += 1;
    if (attempt.count >= 8) { attempt.blockedUntil = Date.now() + 15 * 60_000; attempt.count = 0; }
    loginAttempts.set(ip, attempt);
    return res.status(401).json({ error: 'Contraseña incorrecta.' });
  }
  loginAttempts.delete(ip);
  const secure = APP_BASE_URL.startsWith('https://') ? '; Secure' : '';
  res.setHeader('Set-Cookie', `yadimods_session=${encodeURIComponent(createSession())}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${Math.floor(SESSION_MS/1000)}${secure}`);
  res.json({ ok: true });
});
app.post('/api/auth/logout', (req, res) => {
  const secure = APP_BASE_URL.startsWith('https://') ? '; Secure' : '';
  res.setHeader('Set-Cookie', `yadimods_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure}`);
  res.json({ ok: true });
});
app.use((req, res, next) => {
  if (req.path.startsWith('/api/') && !['/api/health','/api/auth/status','/api/auth/login','/api/auth/logout'].includes(req.path)) return requireAdmin(req, res, next);
  if (req.path === '/auth/tiktok' || req.path === '/auth/instagram' || req.path.startsWith('/api/disconnect/')) return requireAdmin(req, res, next);
  next();
});

function cacheGet(key) {
  const entry = cache.get(key);
  return entry && Date.now() - entry.time < CACHE_MS ? entry.data : null;
}
function cacheSet(key, data) { cache.set(key, { time: Date.now(), data }); }
function makeState(provider) {
  const state = crypto.randomBytes(24).toString('hex');
  oauthStates.set(state, { provider, expires: Date.now() + 10 * 60_000 });
  return state;
}
function consumeState(state, provider) {
  const record = oauthStates.get(state);
  oauthStates.delete(state);
  return Boolean(record && record.provider === provider && record.expires > Date.now());
}
async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  let data;
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
  if (!response.ok) {
    const detail = data?.error?.message || data?.error_description || data?.message || data?.error || `HTTP ${response.status}`;
    throw new Error(String(detail));
  }
  return data;
}
function platformStatus() {
  return {
    youtube: { configured: Boolean(API_KEY), connected: Boolean(API_KEY), label: API_KEY ? 'API configurada' : 'Falta la clave de API' },
    tiktok: { configured: Boolean(TIKTOK_CLIENT_KEY && TIKTOK_CLIENT_SECRET), connected: Boolean(connected.tiktok), label: connected.tiktok ? `Conectado: ${connected.tiktok.display_name || 'TikTok'}` : (TIKTOK_CLIENT_KEY && TIKTOK_CLIENT_SECRET ? 'Listo para autorizar' : 'Faltan credenciales de desarrollador') },
    instagram: { configured: Boolean(INSTAGRAM_APP_ID && INSTAGRAM_APP_SECRET), connected: Boolean(connected.instagram), label: connected.instagram ? `Conectado: @${connected.instagram.username || 'Instagram'}` : (INSTAGRAM_APP_ID && INSTAGRAM_APP_SECRET ? 'Listo para autorizar' : 'Faltan credenciales de Meta') },
    refreshSeconds: 60,
    appBaseUrl: APP_BASE_URL
  };
}

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'YADIMODS Social Live', ...platformStatus() }));
app.get('/api/platform-status', (_req, res) => res.json(platformStatus()));

// YouTube public channel metrics. Public Data API does not expose a channel-wide
// total for likes/comments; those are shown per recent public video instead.
app.get('/api/youtube', async (req, res) => {
  const query = String(req.query.q || '').trim();
  if (!query || query.length > 150) return res.status(400).json({ error: 'Escribe el nombre, @handle o ID del canal.' });
  if (!API_KEY) return res.status(503).json({ error: 'YouTube no está configurado. Añade YOUTUBE_API_KEY en las variables de entorno.' });
  const cacheKey = `youtube:${query.toLowerCase()}`;
  const cached = cacheGet(cacheKey);
  if (cached) return res.json(cached);

  try {
    const isChannelId = /^UC[\w-]{20,}$/.test(query);
    let channelId = isChannelId ? query : null;
    let channel = null;
    if (channelId) {
      const u = new URL('https://www.googleapis.com/youtube/v3/channels');
      u.search = new URLSearchParams({ part: 'snippet,statistics,contentDetails', id: channelId, key: API_KEY });
      const data = await fetchJson(u);
      channel = data.items?.[0] || null;
    } else if (query.startsWith('@')) {
      const u = new URL('https://www.googleapis.com/youtube/v3/channels');
      u.search = new URLSearchParams({ part: 'snippet,statistics,contentDetails', forHandle: query, key: API_KEY });
      const data = await fetchJson(u);
      channel = data.items?.[0] || null;
      channelId = channel?.id || null;
    } else {
      const u = new URL('https://www.googleapis.com/youtube/v3/search');
      u.search = new URLSearchParams({ part: 'snippet', type: 'channel', q: query, maxResults: '5', key: API_KEY });
      const data = await fetchJson(u);
      const candidate = data.items?.[0];
      channelId = candidate?.id?.channelId;
      if (channelId) {
        const cu = new URL('https://www.googleapis.com/youtube/v3/channels');
        cu.search = new URLSearchParams({ part: 'snippet,statistics,contentDetails', id: channelId, key: API_KEY });
        const channelData = await fetchJson(cu);
        channel = channelData.items?.[0] || null;
      }
    }
    if (!channelId || !channel) return res.status(404).json({ error: 'No se encontró el canal. Prueba con el @handle o el ID exacto.' });

    let recentVideos = [];
    const uploadsId = channel.contentDetails?.relatedPlaylists?.uploads;
    if (uploadsId) {
      try {
        const pu = new URL('https://www.googleapis.com/youtube/v3/playlistItems');
        pu.search = new URLSearchParams({ part: 'contentDetails,snippet', playlistId: uploadsId, maxResults: '6', key: API_KEY });
        const playlist = await fetchJson(pu);
        const ids = (playlist.items || []).map(x => x.contentDetails?.videoId).filter(Boolean);
        if (ids.length) {
          const vu = new URL('https://www.googleapis.com/youtube/v3/videos');
          vu.search = new URLSearchParams({ part: 'snippet,statistics', id: ids.join(','), key: API_KEY });
          const videoData = await fetchJson(vu);
          recentVideos = (videoData.items || []).map(v => ({
            id: v.id, title: v.snippet?.title || 'Video', image: v.snippet?.thumbnails?.medium?.url || null,
            url: `https://www.youtube.com/watch?v=${v.id}`, publishedAt: v.snippet?.publishedAt || null,
            views: numberOrNull(v.statistics?.viewCount), likes: numberOrNull(v.statistics?.likeCount), comments: numberOrNull(v.statistics?.commentCount)
          }));
        }
      } catch (err) { console.warn('No se pudieron cargar los videos recientes:', err.message); }
    }
    const data = {
      platform: 'YouTube', id: channel.id, name: channel.snippet?.title || 'Canal de YouTube',
      description: channel.snippet?.description || '', image: channel.snippet?.thumbnails?.high?.url || channel.snippet?.thumbnails?.default?.url || null,
      subscribers: channel.statistics?.hiddenSubscriberCount ? null : numberOrNull(channel.statistics?.subscriberCount),
      views: numberOrNull(channel.statistics?.viewCount), videos: numberOrNull(channel.statistics?.videoCount),
      profileUrl: `https://www.youtube.com/channel/${channel.id}`, recentVideos,
      updatedAt: new Date().toISOString(), source: 'YouTube Data API v3'
    };
    cacheSet(cacheKey, data);
    res.set('Cache-Control', 'no-store');
    res.json(data);
  } catch (error) {
    console.error('YouTube API error:', error.message);
    res.status(502).json({ error: `YouTube: ${error.message}. Revisa la clave, la API habilitada y la cuota.` });
  }
});
function numberOrNull(value) { if (value === undefined || value === null || value === '') return null; const n = Number(value); return Number.isFinite(n) ? n : null; }

// TikTok OAuth (requires an approved TikTok developer app and user consent).
app.get('/auth/tiktok', (_req, res) => {
  if (!TOKEN_ENCRYPTION_KEY) return res.status(503).send('Configura TOKEN_ENCRYPTION_KEY para guardar la conexión cifrada.');
  if (!TIKTOK_CLIENT_KEY || !TIKTOK_CLIENT_SECRET) return res.status(503).send('Faltan TIKTOK_CLIENT_KEY y TIKTOK_CLIENT_SECRET en las variables de entorno.');
  const state = makeState('tiktok');
  const url = new URL('https://www.tiktok.com/v2/auth/authorize/');
  url.search = new URLSearchParams({ client_key: TIKTOK_CLIENT_KEY, response_type: 'code', scope: 'user.info.basic,user.info.stats,video.list', redirect_uri: TIKTOK_REDIRECT_URI, state }).toString();
  res.redirect(url.toString());
});
app.get('/auth/tiktok/callback', async (req, res) => {
  try {
    if (req.query.error) throw new Error(String(req.query.error_description || req.query.error));
    if (!consumeState(String(req.query.state || ''), 'tiktok')) throw new Error('Estado OAuth inválido o vencido. Intenta conectar otra vez.');
    if (!req.query.code) throw new Error('TikTok no devolvió el código de autorización.');
    const body = new URLSearchParams({ client_key: TIKTOK_CLIENT_KEY, client_secret: TIKTOK_CLIENT_SECRET, code: String(req.query.code), grant_type: 'authorization_code', redirect_uri: TIKTOK_REDIRECT_URI });
    const token = await fetchJson('https://open.tiktokapis.com/v2/oauth/token/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Cache-Control': 'no-cache' }, body });
    connected.tiktok = { access_token: token.access_token, refresh_token: token.refresh_token, expires_at: Date.now() + Number(token.expires_in || 86400) * 1000 };
    const me = await fetchJson('https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url,follower_count,following_count,likes_count,video_count', { headers: { Authorization: `Bearer ${token.access_token}` } });
    connected.tiktok = { ...connected.tiktok, ...(me.data?.user || {}) };
    persistConnections();
    cache.delete('tiktok:connected');
    res.redirect('/?connected=tiktok');
  } catch (err) { res.redirect('/?error=' + encodeURIComponent(`TikTok: ${err.message}`)); }
});
app.get('/api/tiktok', async (_req, res) => {
  if (!connected.tiktok?.access_token) return res.status(401).json({ error: 'Conecta TikTok con el botón “Conectar”.' });
  if (connected.tiktok.expires_at && Date.now() > connected.tiktok.expires_at - 60_000) return res.status(401).json({ error: 'La sesión de TikTok venció. Vuelve a conectar la cuenta.' });
  const cached = cacheGet('tiktok:connected'); if (cached) return res.json(cached);
  try {
    const me = await fetchJson('https://open.tiktokapis.com/v2/user/info/?fields=open_id,display_name,avatar_url,follower_count,following_count,likes_count,video_count', { headers: { Authorization: `Bearer ${connected.tiktok.access_token}` } });
    const user = me.data?.user || {};
    let videos = [];
    try {
      const list = await fetchJson('https://open.tiktokapis.com/v2/video/list/?fields=id,title,video_description,create_time,cover_image_url,share_url,view_count,like_count,comment_count,share_count', {
        method: 'POST', headers: { Authorization: `Bearer ${connected.tiktok.access_token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ max_count: 10 })
      });
      videos = (list.data?.videos || []).map(v => ({ id: v.id, title: v.title || v.video_description || 'Video de TikTok', image: v.cover_image_url || null, url: v.share_url || 'https://www.tiktok.com/', views: numberOrNull(v.view_count), likes: numberOrNull(v.like_count), comments: numberOrNull(v.comment_count) }));
    } catch (err) { console.warn('TikTok videos:', err.message); }
    const data = { platform: 'TikTok', id: user.open_id || connected.tiktok.open_id, name: user.display_name || connected.tiktok.display_name || 'TikTok', image: user.avatar_url || connected.tiktok.avatar_url || null, followers: numberOrNull(user.follower_count), likes: numberOrNull(user.likes_count), videos: numberOrNull(user.video_count), views: videos.reduce((sum, v) => sum + (v.views || 0), 0), comments: videos.reduce((sum, v) => sum + (v.comments || 0), 0), profileUrl: 'https://www.tiktok.com/', recentVideos: videos, updatedAt: new Date().toISOString(), source: 'TikTok API' };
    cacheSet('tiktok:connected', data); res.set('Cache-Control', 'no-store'); res.json(data);
  } catch (err) { res.status(502).json({ error: `TikTok: ${err.message}. Comprueba los permisos user.info.stats y video.list.` }); }
});

// Instagram Login API. This only works for eligible professional accounts and
// requires the corresponding scopes/app configuration in Meta Developer Console.
app.get('/auth/instagram', (_req, res) => {
  if (!TOKEN_ENCRYPTION_KEY) return res.status(503).send('Configura TOKEN_ENCRYPTION_KEY para guardar la conexión cifrada.');
  if (!INSTAGRAM_APP_ID || !INSTAGRAM_APP_SECRET) return res.status(503).send('Faltan INSTAGRAM_APP_ID e INSTAGRAM_APP_SECRET en las variables de entorno.');
  const state = makeState('instagram');
  const url = new URL('https://www.instagram.com/oauth/authorize');
  url.search = new URLSearchParams({ client_id: INSTAGRAM_APP_ID, redirect_uri: INSTAGRAM_REDIRECT_URI, response_type: 'code', scope: 'instagram_business_basic,instagram_business_manage_insights', state, enable_fb_login: '0', force_authentication: '1' }).toString();
  res.redirect(url.toString());
});
app.get('/auth/instagram/callback', async (req, res) => {
  try {
    if (req.query.error) throw new Error(String(req.query.error_description || req.query.error));
    if (!consumeState(String(req.query.state || ''), 'instagram')) throw new Error('Estado OAuth inválido o vencido. Intenta conectar otra vez.');
    if (!req.query.code) throw new Error('Instagram no devolvió el código de autorización.');
    const body = new URLSearchParams({ client_id: INSTAGRAM_APP_ID, client_secret: INSTAGRAM_APP_SECRET, grant_type: 'authorization_code', redirect_uri: INSTAGRAM_REDIRECT_URI, code: String(req.query.code) });
    const token = await fetchJson('https://api.instagram.com/oauth/access_token', { method: 'POST', body });
    let accessToken = token.access_token;
    // Exchange for a long-lived token when Meta accepts the exchange.
    try {
      const longUrl = new URL('https://graph.instagram.com/access_token');
      longUrl.search = new URLSearchParams({ grant_type: 'ig_exchange_token', client_secret: INSTAGRAM_APP_SECRET, access_token: accessToken });
      const longToken = await fetchJson(longUrl);
      if (longToken.access_token) accessToken = longToken.access_token;
    } catch (err) { console.warn('Instagram token exchange:', err.message); }
    connected.instagram = { access_token: accessToken, user_id: token.user_id, expires_at: Date.now() + 50 * 24 * 60 * 60 * 1000 };
    persistConnections();
    cache.delete('instagram:connected');
    res.redirect('/?connected=instagram');
  } catch (err) { res.redirect('/?error=' + encodeURIComponent(`Instagram: ${err.message}`)); }
});
app.get('/api/instagram', async (_req, res) => {
  if (!connected.instagram?.access_token) return res.status(401).json({ error: 'Conecta Instagram con el botón “Conectar”.' });
  const cached = cacheGet('instagram:connected'); if (cached) return res.json(cached);
  try {
    const base = `https://graph.instagram.com/${INSTAGRAM_API_VERSION}/me`;
    const profileUrl = new URL(base);
    profileUrl.search = new URLSearchParams({ fields: 'user_id,username,account_type,media_count,followers_count', access_token: connected.instagram.access_token });
    let profile;
    try { profile = await fetchJson(profileUrl); }
    catch (err) {
      // Some app configurations do not expose followers_count on /me; preserve supported fields.
      const fallback = new URL(base); fallback.search = new URLSearchParams({ fields: 'user_id,username,account_type,media_count', access_token: connected.instagram.access_token });
      profile = await fetchJson(fallback); profile._followersUnavailable = true;
    }
    const mediaUrl = new URL(`https://graph.instagram.com/${INSTAGRAM_API_VERSION}/me/media`);
    mediaUrl.search = new URLSearchParams({ fields: 'id,caption,media_type,permalink,timestamp,like_count,comments_count,thumbnail_url,media_url', limit: '10', access_token: connected.instagram.access_token });
    let media = [];
    try {
      const mediaData = await fetchJson(mediaUrl);
      media = (mediaData.data || []).map(item => ({ id: item.id, title: (item.caption || '').slice(0, 100) || item.media_type || 'Publicación', image: item.thumbnail_url || item.media_url || null, url: item.permalink || 'https://www.instagram.com/', likes: numberOrNull(item.like_count), comments: numberOrNull(item.comments_count), views: null }));
    } catch (err) { console.warn('Instagram media:', err.message); }
    const data = { platform: 'Instagram', id: profile.user_id || connected.instagram.user_id, name: profile.username ? `@${profile.username}` : 'Instagram', username: profile.username || '', image: null, followers: numberOrNull(profile.followers_count), posts: numberOrNull(profile.media_count), likes: media.reduce((sum, x) => sum + (x.likes || 0), 0), comments: media.reduce((sum, x) => sum + (x.comments || 0), 0), views: null, profileUrl: profile.username ? `https://www.instagram.com/${profile.username}/` : 'https://www.instagram.com/', recentVideos: media, updatedAt: new Date().toISOString(), source: 'Instagram Graph API', notes: profile._followersUnavailable ? 'La API de esta app no expone el total de seguidores; se muestran los campos disponibles.' : '' };
    cacheSet('instagram:connected', data); res.set('Cache-Control', 'no-store'); res.json(data);
  } catch (err) { res.status(502).json({ error: `Instagram: ${err.message}. Revisa que sea una cuenta profesional y que los permisos estén aprobados.` }); }
});

app.get('/api/dashboard', async (_req, res) => {
  const result = {};
  for (const platform of ['tiktok', 'instagram']) {
    try {
      const data = cacheGet(`${platform}:connected`);
      result[platform] = data ? { connected: true, data } : { connected: Boolean(connected[platform]?.access_token), available: Boolean(connected[platform]?.access_token) };
    } catch { result[platform] = { connected: false }; }
  }
  res.json({ status: platformStatus(), accounts: result });
});

app.get('/api/disconnect/:platform', (req, res) => {
  const platform = req.params.platform;
  if (!['tiktok', 'instagram'].includes(platform)) return res.status(404).json({ error: 'Plataforma no válida.' });
  connected[platform] = null; persistConnections(); cache.delete(`${platform}:connected`);
  res.redirect('/?disconnected=' + platform);
});

if (process.env.NODE_ENV === 'production' && (!ADMIN_PASSWORD || !SESSION_SECRET || !TOKEN_ENCRYPTION_KEY)) {
  console.error('CONFIGURACIÓN INCOMPLETA: define ADMIN_PASSWORD, SESSION_SECRET y TOKEN_ENCRYPTION_KEY antes de publicar en producción.');
}
app.listen(PORT, '0.0.0.0', () => console.log(`YADIMODS Social Live listo en ${APP_BASE_URL}`));
