# YADIMODS Social Live — versión ampliada

Panel web responsive rojo/negro para consultar estadísticas oficiales de YouTube y, cuando se configuran credenciales y permisos, conectar una cuenta autorizada de TikTok o Instagram.

## Qué incluye

- **YouTube:** búsqueda por nombre, `@handle` o ID de canal; suscriptores visibles, visualizaciones del canal, cantidad de videos y métricas de vistas/likes/comentarios de hasta seis videos recientes.
- **TikTok:** flujo OAuth de conexión, seguidores, likes, número de videos y métricas de hasta diez videos recientes, según los permisos concedidos por TikTok.
- **Instagram:** flujo Instagram Login, perfil y publicaciones recientes con likes/comentarios disponibles, según tipo de cuenta, versión de API y permisos de Meta.
- Panel privado con contraseña de administrador, cookie HttpOnly/SameSite, sesión firmada de 8 horas, limitación de intentos y cabeceras de seguridad.
- Tokens de TikTok e Instagram cifrados con AES-256-GCM en disco, si se configura `TOKEN_ENCRYPTION_KEY` y un disco persistente.
- Botones para conectar/desconectar, estados de conexión, manejo de errores y actualización automática cada 60 segundos.
- Caché de 60 segundos para reducir llamadas a las APIs.

## Requisitos

- Node.js 18 o superior.
- Clave de YouTube Data API v3.
- Para TikTok: aplicación registrada en TikTok for Developers, credenciales válidas y acceso aprobado a los productos/scopes `user.info.basic`, `user.info.stats` y `video.list`.
- Para Instagram: aplicación en Meta for Developers configurada para Instagram Login, credenciales válidas, cuenta profesional elegible y permisos requeridos, incluyendo `instagram_business_basic` y `instagram_business_manage_insights` cuando estén disponibles para tu aplicación.
- URLs de retorno OAuth configuradas exactamente como se indica abajo.

## Ejecutar en tu Mac

1. Descomprime el ZIP y abre Terminal en la carpeta `yadimods`.
2. Ejecuta `npm install`.
3. Copia `.env.example` a `.env`.
4. Rellena `SESSION_SECRET`, `TOKEN_ENCRYPTION_KEY` y las credenciales de las APIs en `.env`. La contraseña inicial de administrador configurada en `.env.example` es `YADIMODS01`; cámbiala por una contraseña fuerte antes de publicar el panel en internet. Para generar secretos en Mac, ejecuta `openssl rand -hex 32` tres veces y usa valores distintos. No compartas ese archivo ni publiques las claves.
5. Ejecuta `npm start`.
6. Abre `http://localhost:3000`.

## Configurar YouTube

1. Entra en https://console.cloud.google.com/.
2. Crea/elige un proyecto y habilita **YouTube Data API v3**.
3. Crea una API key y limita su uso según la guía de Google.
4. Ponla en `YOUTUBE_API_KEY`.

## Configurar TikTok

1. Registra la aplicación en https://developers.tiktok.com/ y habilita los productos/permisos necesarios.
2. Registra la URL de retorno: `https://TU-DOMINIO/auth/tiktok/callback` (para pruebas locales: `http://localhost:3000/auth/tiktok/callback`).
3. Configura `TIKTOK_CLIENT_KEY` y `TIKTOK_CLIENT_SECRET`.
4. Si TikTok exige revisión/aprobación para tus scopes, debes obtenerla en el portal de desarrolladores. El botón no puede saltarse esa revisión.

## Configurar Instagram

1. Crea/configura una app en https://developers.facebook.com/ y habilita Instagram Login para tu caso de uso.
2. Registra la URL de retorno: `https://TU-DOMINIO/auth/instagram/callback` (para pruebas locales: `http://localhost:3000/auth/instagram/callback`).
3. Configura `INSTAGRAM_APP_ID` y `INSTAGRAM_APP_SECRET`.
4. Usa una cuenta profesional compatible y completa los permisos/revisión que solicite Meta.

## Publicar en Render

El archivo `render.yaml` prepara un servicio de Node.js, variables secretas y un disco persistente para las conexiones cifradas. Render exige una cuenta y que el código esté en un repositorio Git conectado; no se puede publicar desde este ZIP sin autorizar esa cuenta.

1. Sube el contenido de esta carpeta a un repositorio **privado** de GitHub. No subas `.env` ni claves.
2. En Render, selecciona **New → Blueprint** y conecta el repositorio; Render leerá `render.yaml`.
3. En la configuración inicial, proporciona `ADMIN_PASSWORD` (usa `YADIMODS01` si quieres mantener la contraseña solicitada) y `YOUTUBE_API_KEY`. Añade también las credenciales de TikTok y Meta cuando las tengas.
4. Después del despliegue, abre la URL HTTPS que Render asigne. `APP_BASE_URL` se toma automáticamente de `RENDER_EXTERNAL_URL`.
5. Copia las URL exactas `/auth/tiktok/callback` y `/auth/instagram/callback` a los portales de desarrollador.
6. Comprueba `/api/health`; inicia sesión en el panel y prueba primero YouTube.

El disco persistente de Render requiere un plan de pago; sin almacenamiento persistente, el sistema de archivos puede perder los tokens guardados al reiniciar o desplegar. Consulta https://render.com/docs/disks y https://render.com/docs/blueprint-spec. La contraseña del administrador debe ser larga, única y mantenerse privada.

## Endpoints

- `GET /api/health` — salud y configuración general.
- `GET /api/platform-status` — estado de conectores.
- `GET /api/youtube?q=...` — canal y videos recientes de YouTube.
- `GET /auth/tiktok` y `GET /auth/instagram` — inician OAuth.
- `GET /api/tiktok` y `GET /api/instagram` — métricas de las cuentas autorizadas.
- `GET /api/disconnect/tiktok` y `/api/disconnect/instagram` — desconectar cuentas.

## Limitaciones importantes

- **No es posible garantizar “100%” sin tus claves, la configuración del portal de desarrolladores, permisos aprobados y una URL HTTPS publicada.** El código queda preparado, pero esos pasos externos son obligatorios.
- Las APIs no permiten leer todas las métricas de cualquier perfil público de TikTok/Instagram. El usuario/cuenta debe autorizar el acceso y cumplir las condiciones de la plataforma.
- YouTube Data API pública no proporciona un total general de likes o comentarios de todo el canal; esos datos se muestran por video. Los contadores de suscriptores pueden estar redondeados u ocultos.
- Esta versión está diseñada para un único administrador. Los tokens OAuth se cifran con AES-256-GCM y se guardan en `DATA_DIR`; en hosting debe apuntar a un disco persistente. Si se pierde o cambia `TOKEN_ENCRYPTION_KEY`, los tokens almacenados no se podrán descifrar.
- La actualización automática ocurre cada 60 segundos mientras la página esté abierta; no significa que las plataformas actualicen sus métricas en tiempo real.
- No se usa scraping ni se inventan métricas.
